lokasi_kerja <- "A:/Tugas/semester 3/data mining/tugas besar"
setwd(lokasi_kerja)
getwd()

install.packages("tidyverse")
library(tidyverse)

bank <- read.csv("bank-full.csv", sep=";")

str(bank)

table(is.na(bank))

binnum <- length(unique(bank$age))

ggplot(bank, aes(age, fill = y)) + 
  geom_histogram(bins = binnum) + 
  ggtitle("usia pelanggan dan bukan pelanggan") +
  xlab("usia") + 
  ylab("Jumlah pelanggan") +
  theme_bw() +
  scale_fill_brewer(palette="Set3") +
  theme(legend.title=element_blank())

yn <- bank %>% group_by(education, y) %>% summarise(n = n())
yed <- bank %>% group_by(education) %>% summarise(n = n())
jed <- left_join(yn, yed, by = "education")
jed <- jed %>% mutate(perc = round((n.x / n.y) * 100, digits = 0))

ggplot(jed, aes(x = education, y = perc, fill = y, label = perc)) + 
  geom_bar(stat = "identity", alpha = 0.7) + 
  geom_text(position = "stack", size = 6) + 
  ggtitle("Persentasi pelanggan berdasarkan tingkat pendidikan") + 
  xlab("") +
  ylab("% Pelanggan") +
  scale_fill_brewer(palette="Set3") +
  theme_bw() +
  theme(legend.title=element_blank()) +
  coord_flip()

mar <- bank %>% group_by(marital, y) %>% summarise(n = n())
ymar <- bank %>% group_by(marital) %>% summarise(n = n())
jmar <- left_join(mar, ymar, by = "marital")
jmar <- jmar %>% mutate(perc = round((n.x / n.y) * 100, digits = 0))

ggplot(jmar, aes(x = marital, y = perc, fill = y, label = perc)) + 
  geom_bar(stat = "identity", alpha = 0.7) + 
  geom_text(position = "stack", size = 6)  + 
  scale_fill_brewer(palette="Spectral") +
  ggtitle("Persentasi pelanggan berdasarkan status perkawinan") +
  xlab("") +
  ylab("% Pelanggan") +
  theme_bw() +
  theme(legend.title=element_blank())+
  coord_flip()

ageout <- data.frame(table(bank$job, bank$y))
colnames(ageout) <- c("job", "y", "Freq")
jobs <- bank %>% group_by(job) %>% summarise(n = n())
aj <- left_join(ageout, jobs, by = "job")
aj <- aj %>% mutate(perc = round((Freq / n) * 100, digits = 0))

ggplot(aj, aes(x = job, y = perc, fill = y, label = perc)) + 
  geom_bar(stat = "identity", alpha = 0.7) + 
  geom_text(position = "stack", size = 4)  + 
  scale_fill_brewer(palette="Set2") +
  ggtitle("Persentasi pelanggan berdasarkan jenis pekerjaan") +
  xlab("") +
  ylab("% Pelanggan") +
  theme_bw() +
  theme(legend.title=element_blank())+
  coord_flip()

age <- bank %>% group_by(age, y) %>% summarise(n = n())
yage <- bank %>% group_by(age) %>% summarise(n = n())
jage <- left_join(age, yage, by = "age")
jage <- jage %>% mutate(perc = round((n.x / n.y) * 100, digits = 1))

ggplot(jage, aes(x = age, y = perc, fill = y, label = perc)) + 
  geom_bar(stat = "identity", position = "dodge", alpha = 0.6) + 
  scale_fill_brewer(palette="Paired") +
  ggtitle("Persentasi Pelanggan berdasarkan usia") +
  xlab("Usia") +
  ylab("% Pelanggan") +
  theme_bw() +
  theme(legend.title=element_blank())

#H2O
pkgs <- c("RCurl","jsonlite")
for (pkg in pkgs) {
  if (! (pkg %in% rownames(installed.packages()))) { install.packages(pkg) }
}

install.packages("h2o", type="source", repos=(c("http://h2o-release.s3.amazonaws.com/h2o/latest_stable_R")))

library(h2o)
localH2O = h2o.init()
demo(h2o.kmeans)

h2o.init(nthreads = -1)

train.hex <- h2o.importFile("A:/Tugas/semester 3/data mining/tugas besar/bank-full.csv")

summary(train.hex)

splits <- h2o.splitFrame(train.hex, 0.75, seed=1234)

gbm <- h2o.gbm(x = c(2:9), y = 17,
               training_frame = splits[[1]])

pred <- h2o.predict(gbm, splits[[2]])

tester <- as.data.frame(splits[[2]])
pred_df <- as.data.frame(pred)

pred_df$yn <- ifelse(pred_df$no > 0.6, "no", "yes")

confusionMatrix(tester$y, pred_df$yn)
